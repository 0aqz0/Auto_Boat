////////////////////////////////////////////////////////////
//	Public functions
////////////////////////////////////////////////////////////

// Global variable
var g_objRegistry = null;
var g_nRegistryType = 0;
var g_bsComponent = null;

// g_iMobielActive = -1, bluesoleil isen.exe is not running
//g_iMobileActive = 0, mobile active false, bs7
//g_iMobileActive = 1, mobile active true, bs8
var g_iMobielActive = -1;

createBlueSoleilComponent();

// Registry access
// root key values:
// 0: HKEY_CLASSES_ROOT = 0x80000000
// 1: HKEY_CURRENT_CONFIG = 0x80000005
// 2: HKEY_CURRENT_USER = 0x80000001
// 3: HKEY_LOCAL_MACHINE = 0x80000002
// 4: HKEY_USERS = 0x80000003
function createRegistryObject()
{
	if(g_objRegistry)
		return true;
	
	if ("@mozilla.org/windows-registry-key;1" in Components.classes)
	{
		g_objRegistry = Components.classes["@mozilla.org/windows-registry-key;1"].createInstance(Components.interfaces.nsIWindowsRegKey);
		g_nRegistryType = 2;
	}
	else if("@mozilla.org/winhooks;1" in Components.classes)
	{
		g_objRegistry = Components.classes["@mozilla.org/winhooks;1"].getService(Components.interfaces.nsIWindowsRegistry);
		g_nRegistryType = 1;
	}
	else if("@mozilla.org/browser/shell-service;1" in Components.classes)
	{
		g_objRegistry = Components.classes["@mozilla.org/browser/shell-service;1"].getService(Components.interfaces.nsIWindowsShellService);
		g_nRegistryType = 1;
	}
	else
	{
		g_objRegistry = null;
		g_nRegistryType = 0;
	}
	
	if(g_nRegistryType == 0)
		return false;
	return true;
}

function regReadString(strPath, strName)
{
	if(!createRegistryObject())
		return false;
		
	var bRet = true;

	try
	{
		if(g_nRegistryType == 1)
		{
			if ("" == g_objRegistry.getRegistryEntry(3, strPath, strName))
			{
				bRet = false;
			}
		}
		else if(g_nRegistryType == 2)
		{
			g_objRegistry.open(Components.interfaces.nsIWindowsRegKey.ROOT_KEY_LOCAL_MACHINE,
							   strPath, Components.interfaces.nsIWindowsRegKey.ACCESS_READ);
			if ("" == g_objRegistry.readStringValue(strName))
			{
				bRet = false;
			}
		}
	}
	catch(err)
	{
		bRet = false;
	}

	return bRet;
}

// create BlueSoleil component
function createBlueSoleilComponent()
{
	if(g_bsComponent == null)
	{
		try
		{
			g_bsComponent = Components.classes["@bluesoleil.com/TransSend;1"].createInstance();
			g_bsComponent = g_bsComponent.QueryInterface(Components.interfaces.IFFTransSend);
		}
		catch(err)
		{
			alert(err);
			return;
		}
	}
}

// get BlueSoleil path
function checkBlueSoleil()
{
	var bRet = regReadString("SOFTWARE\\IVT Corporation\\BlueSoleil\\Install", "InstallDir");
	g_iMobielActive = g_bsComponent.CheckMobileActive();	
	return bRet;
}

// call BlueSoleil
function callBlueSoleil(strUrls, strInfo, iType)
{
	// createBlueSoleilComponent();
	g_bsComponent.CallBlueSoleil(strUrls, strInfo, iType);
}


