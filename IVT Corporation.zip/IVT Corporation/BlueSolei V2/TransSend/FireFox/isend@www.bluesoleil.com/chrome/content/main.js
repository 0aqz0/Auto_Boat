
////////////////////////////////////////////////////////////
//	Event handler
////////////////////////////////////////////////////////////
function OnBsContextMenu(event)
{
	if (checkBlueSoleil())
	{
		if(g_iMobielActive >= 0)
		{
			if (gContextMenu.isTextSelected || gContextMenu.onImage)
			{
				document.getElementById("BlueSoleilTransSend").setAttribute("hidden", false);
				document.getElementById("BlueSoleilUp").setAttribute("hidden", false);
				if (gContextMenu.isTextSelected)
				{
					if(g_iMobielActive == 1)
					{
						document.getElementById("BlueSoleilTransSendSms").setAttribute("hidden", false);
					}
					else
					{
						document.getElementById("BlueSoleilTransSendSms").setAttribute("hidden", true);						
					}
				}
				else
				{
					document.getElementById("BlueSoleilTransSendSms").setAttribute("hidden", true);
				}
			}
			else
			{
				document.getElementById("BlueSoleilTransSend").setAttribute("hidden", true);
				document.getElementById("BlueSoleilUp").setAttribute("hidden", true);
				document.getElementById("BlueSoleilTransSendSms").setAttribute("hidden", true);			
			}
		}
		else
		{
			document.getElementById("BlueSoleilTransSend").setAttribute("hidden", true);
			document.getElementById("BlueSoleilUp").setAttribute("hidden", true);	
			document.getElementById("BlueSoleilTransSendSms").setAttribute("hidden", true);
		}
		
	}
	else
	{
		document.getElementById("BlueSoleilTransSend").setAttribute("hidden", true);
		document.getElementById("BlueSoleilUp").setAttribute("hidden", true);	
		document.getElementById("BlueSoleilTransSendSms").setAttribute("hidden", true);
	}	
}

function OnBsTransSend(event)
{
	// Get current page URL
	var strUrls = document.commandDispatcher.focusedWindow.document.URL;
	var strInfo = 0;
	var iType = 0;
	
	if (gContextMenu.isTextSelected)
	{
		strInfo = document.commandDispatcher.focusedWindow.document.getSelection();
		iType = 0;
	}
	else if (gContextMenu.onImage)
	{
		strInfo = gContextMenu.target.src;
		iType = 1;
	}
	
	// Call BlueSoleil
	callBlueSoleil(strUrls, strInfo, iType);
}

function OnBsTransSendSms(event)
{
	// Get current page URL
	var strUrls = document.commandDispatcher.focusedWindow.document.URL;
	var strInfo = 0;
	var iType = 2;
	
	strInfo = document.commandDispatcher.focusedWindow.document.getSelection();
	
	// Call BlueSoleil
	callBlueSoleil(strUrls, strInfo, iType);
}

